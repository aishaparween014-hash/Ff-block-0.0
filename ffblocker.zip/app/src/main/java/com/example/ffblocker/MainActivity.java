package com.example.ffblocker;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final int BG = Color.parseColor("#0D0F1A");
    static final int CARD = Color.parseColor("#181B2E");
    static final int ACCENT = Color.parseColor("#FF5A36");
    static final int TEXT = Color.WHITE;
    static final int MUTED = Color.parseColor("#9AA0B8");
    static final int GREEN = Color.parseColor("#3DDC84");

    SharedPreferences p;
    Switch sw;
    EditText min;
    TextView status, accStatus;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable tick = new Runnable() {
        public void run() {
            refresh();
            h.postDelayed(this, 1000);
        }
    };

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    GradientDrawable box(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    TextView label(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(box(CARD, 20));
        c.setPadding(dp(20), dp(20), dp(20), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16);
        c.setLayoutParams(lp);
        return c;
    }

    boolean accOn() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(getPackageName() + "/");
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("cfg", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(48), dp(20), dp(32));
        scroll.addView(root);

        TextView title = label("🔥 FF Blocker", 30, ACCENT, true);
        TextView sub = label("Free Fire और Free Fire MAX को ब्लॉक करो", 14, MUTED, false);
        root.addView(title);
        root.addView(sub);

        // Timer card
        LinearLayout c1 = card();
        c1.addView(label("⏱ कितने मिनट बाद ब्लॉक हो?", 16, TEXT, true));
        c1.addView(label("0 डालोगे तो तुरंत ब्लॉक हो जाएगा", 13, MUTED, false));
        min = new EditText(this);
        min.setInputType(InputType.TYPE_CLASS_NUMBER);
        min.setText(String.valueOf(p.getInt("delay", 0)));
        min.setTextColor(TEXT);
        min.setHintTextColor(MUTED);
        min.setHint("मिनट");
        min.setTextSize(28);
        min.setGravity(Gravity.CENTER);
        min.setBackground(box(Color.parseColor("#232742"), 14));
        min.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2);
        mlp.topMargin = dp(12);
        min.setLayoutParams(mlp);
        c1.addView(min);
        root.addView(c1);

        // Switch card
        LinearLayout c2 = card();
        sw = new Switch(this);
        sw.setText("Free Fire ब्लॉक  ON / OFF");
        sw.setTextSize(18);
        sw.setTextColor(TEXT);
        sw.setTypeface(Typeface.DEFAULT_BOLD);
        sw.setChecked(p.getBoolean("enabled", false));
        c2.addView(sw);
        status = label("", 15, MUTED, false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = dp(12);
        status.setLayoutParams(slp);
        c2.addView(status);
        root.addView(c2);

        // Permission card
        LinearLayout c3 = card();
        c3.addView(label("🔐 परमिशन", 16, TEXT, true));
        accStatus = label("", 14, MUTED, false);
        c3.addView(accStatus);
        Button acc = new Button(this);
        acc.setText("Accessibility परमिशन दो");
        acc.setTextColor(Color.WHITE);
        acc.setAllCaps(false);
        acc.setBackground(box(ACCENT, 14));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(52));
        blp.topMargin = dp(12);
        acc.setLayoutParams(blp);
        acc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        c3.addView(acc);
        c3.addView(label("Settings में 'FF Blocker' चुनकर ON करो। अगर 'Restricted setting' आए तो Settings → Apps → FF Blocker → ⋮ → Allow restricted settings।", 12, MUTED, false));
        root.addView(c3);

        setContentView(scroll);

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean on) {
                int m = 0;
                try { m = Integer.parseInt(min.getText().toString().trim()); } catch (Exception e) {}
                SharedPreferences.Editor e = p.edit();
                e.putBoolean("enabled", on);
                e.putInt("delay", m);
                e.putLong("endTime", System.currentTimeMillis() + m * 60000L);
                e.apply();
                if (on && !accOn()) {
                    Toast.makeText(MainActivity.this, "पहले Accessibility परमिशन ON करो", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                }
                refresh();
            }
        });
    }

    void refresh() {
        boolean on = p.getBoolean("enabled", false);
        long left = p.getLong("endTime", 0) - System.currentTimeMillis();
        if (!on) {
            status.setTextColor(MUTED);
            status.setText("ब्लॉक बंद है");
        } else if (left > 0) {
            long s = left / 1000;
            status.setTextColor(ACCENT);
            status.setText(String.format("⏳ ब्लॉक शुरू होगा: %02d:%02d में", s / 60, s % 60));
        } else {
            status.setTextColor(GREEN);
            status.setText("🔒 Free Fire अभी ब्लॉक है");
        }
        if (accOn()) {
            accStatus.setTextColor(GREEN);
            accStatus.setText("✅ परमिशन चालू है");
        } else {
            accStatus.setTextColor(ACCENT);
            accStatus.setText("❌ परमिशन बंद है, नीचे बटन दबाओ");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(tick);
        super.onPause();
    }
}
