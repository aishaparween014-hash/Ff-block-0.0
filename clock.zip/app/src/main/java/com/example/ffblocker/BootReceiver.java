package com.example.ffblocker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (KeepAliveService.enabled(c)) KeepAliveService.start(c);
    }
}
